# COVID19
Negative binomial model for projecting COVID-19 deaths from Johns Hopkins data.
See the doc `20200429 Squashing the sombrero - negative binomial model for COVID-19 deaths.pdf`, the addition of time-varying survival rates as documented in `20200512 COVID-19 deaths projection now uses time-varying survival rate.pdf` and most recently weekday seasonality in `20200519 weekday seasonality added to COVID-19 deaths projection.pdf`.
